#include <iostream>
#include "functions.h"
void print(double r) {
	std::cout<<"\033[0;32m"<<r<<"\033[0m\n";
}