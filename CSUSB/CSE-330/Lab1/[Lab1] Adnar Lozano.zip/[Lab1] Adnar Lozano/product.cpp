#include "functions.h"
double product(double a, double b) {
	return a * b;
}
