#include <iostream>
#include <stdlib.h>
#include "functions.h"

int main(int argc, char* argv[]) {

	double a = atof(argv[1]);
	double b = atof(argv[2]);
	if ( (a==0)||(b==0) )
		std::cout<<"\033[0;31mInvalid input. "
			  "Enter numbers only\033[0m\n";
	else {
		double result = product(a, b);
		print(result);	
	}
	return 0;
}