#ifndef FUNCTIONS_H
#define FUNCTIONS_H

extern double product(double a, double b);
extern void print(double r);

#endif