/*input
25
*/
// Adnar Lozano
// CSE 330 Data Structures
// Lab 5 (Trees)
// 5/4/17

#include <iostream>
#include <queue>
using namespace std;
class Node {
public:
	int data;
	Node* left;
	Node* right;
};
Node* GetNewNode(int data) {
	Node* newNode = new Node();
	newNode->data = data;
	newNode->left = NULL;
	newNode->right = NULL;
	return newNode;
}
Node* Insert(Node* root, int data) {
	if (root == NULL) {
		root = GetNewNode(data);
	}
	else if (data <= root->data)
		root->left = Insert(root->left, data);
	else root->right = Insert(root->right, data);
	return root;
}
bool Search(Node* root, int data) {
	if(root == NULL)
		return false;
	else if (root->data == data)
		return true;
	else if (data <= root->data)
		return Search(root->left, data);
	else return Search(root->right, data);
}
// Recursive Function
int FindMin(Node* root) {
	if (root == NULL) {
		cout << "Error: Tree is empty\n";
		return -1;
	}
	while (root->left == NULL)
		return root ->data;
	return FindMin(root->left);
}
// Iterative function
int FindMax(Node* root) {
	if (root == NULL) {
		cout << "Error: Tree is empty\n";
		return -1;
	}
	while (root->right != NULL)
		root = root->right;
	return root->data;
}
int FindHeight(Node* root) {
	if (root == NULL) return -1;
	return max(FindHeight(root->left), FindHeight(root->right))+1;
}
void LevelOrder(Node* root) {
	if(root == NULL) return;
	queue<Node*> Q;
	Q.push(root);
 	while(!Q.empty()) {
		Node* root = Q.front();
		cout << root->data << " ";
		if(root->left != NULL) Q.push(root->left);
		if(root->right != NULL) Q.push(root->right);
		Q.pop();
	}
}
void PreOrder(Node* root) {
	if(root == NULL) return;
	cout << root->data << " ";
	PreOrder(root->left);
	PreOrder(root->right);
}
void InOrder(Node* root) {
	if(root == NULL) return;
	InOrder(root->left);
	cout << root->data << " ";
	InOrder(root->right);
}
void PostOrder(Node* root) {
	if(root == NULL) return;
	PostOrder(root->left);
	PostOrder(root->right);
	cout << root->data << " ";
}
bool IsBST(Node* root) {
	if(root == NULL) return true;
	if(root->data > INT_MIN && root->data < INT_MAX
		&& IsBST(root->left)
		&& IsBST(root->right))
		return true;
	else return false;
}
int main() {
	Node* root = NULL;
	root = Insert(root,15);
	root = Insert(root,10);
	root = Insert(root,20);
	root = Insert(root,12);
	root = Insert(root,25);
	root = Insert(root,5);
	root = Insert(root,35);
	int number;
	cout << "Enter number to search: ";
	cin >> number;
	cout << number << endl;
	if (Search(root,number) == true) cout << "Number was Found\n";
	else cout << "Number was Not found\n";
	cout << "Root: " << root->data << endl;
	cout << "Min value is: " << FindMin(root) << endl;
	cout << "Max value is: " << FindMax(root) << endl;
	cout << "Height is: " << FindHeight(root) << endl;
	cout << "LevelOrder: ";
	LevelOrder(root);
	cout << endl;
	cout << "PreOrder: ";
	PreOrder(root);
	cout << endl;
	cout << "InOrder: ";
	InOrder(root);
	cout << endl;
	cout << "PostOrder: ";
	PostOrder(root);
	cout << endl;
	if (IsBST(root) == true) cout << "It's a Binary Tree\n";
	else cout << "Not a Binary Tree\n";
	return 0;
}